package Cloacalandia

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession


object Cloacalandia_ListaNegra {


      def main(args: Array[String]): Unit = {
      Logger.getLogger("org").setLevel(Level.ERROR)


      val spark=SparkSession
        .builder()
        .appName("Cloacalandia2")
        .master("local")
        .getOrCreate()

        /*Como no he podido guardar la informacion del Streaming en un fichero externo,
        voy a simular lo que he hecho en el programa Cloacalandia_Streaming: parto de mi fichero "mensajes.txt" que es el mismo que
        le he pasado a kafka. NOTA: el fichero no puede contener ningún tipo de tildes para el buen conteo de palabras*/

        val textFile= spark.sparkContext.textFile("data/mensajes")

        /*Simulo lo que ha hecho mi programa Cloacalandia_Streaming para contar el número de apariciones de cada palabra."Simulo" el conteo
        de palabras de una sola ventana de tiempo de 1 hora.*/
            val counts = textFile.flatMap(line => line.split("\\W+|\\d"))
              .filter(_!="").filter(_!="de").filter(_!="a")
              .filter(_!="el").filter(_!="la").filter(_!="los").filter(_!="las")
              .filter(_!="un").filter(_!="unos").filter(_!="unas").filter(_!="en").map(_.toLowerCase)
              .map(word => (word, 1))
              .reduceByKey(_ + _)


        //Calculo las 10 palabras mas repetidas y las imprimo
             val texto=counts.map(item => item.swap).sortByKey(ascending = false).map(word=>word._2).take(10)

             texto.foreach(println)

        val listaNegra="plaza, rebelion, reunion, gobierno, ataque "

        //Cruzo la palabra más repetida con listaNegra para saber si se planea una rebelión contra el gobierno
        //Si y sólo si la palabra más repetida está dentro de Lista Negra, enviaré una notificación "Se planea un ataque al gobierno. Palabra interceptada:"
        val palabras = listaNegra.split(",")
        for (i <- palabras) {
          if (texto contains i) {
            System.out.println(s"Se planea un ataque al gobierno. Palabra interceptada: ${i}")
          }
        }



  spark.sparkContext.stop()
}



}
