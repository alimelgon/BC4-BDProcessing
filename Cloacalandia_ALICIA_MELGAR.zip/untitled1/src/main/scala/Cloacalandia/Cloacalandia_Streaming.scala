package Cloacalandia

import java.sql.Timestamp

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object Cloacalandia_Streaming {
  def main(args: Array[String]): Unit = {
    Logger.getLogger("org").setLevel(Level.ERROR)



    val spark = SparkSession
      .builder()
      .appName("Cloacalandia")
      .master("local")
      .getOrCreate()

    //lectura en streaming desde kafka (introduzco el fichero "mensajes.txt" como fuente de datos del topic cloacalandia)
    val info = spark.readStream
      .format("kafka")
     .option("kafka.bootstrap.servers", "localhost:9092")
     .option("subscribe", "cloacalandia")
     .option("includeTimestamp", value = true)
      .load()
      .selectExpr("CAST(value AS STRING)", "timestamp AS TIMESTAMP")


    import spark.implicits._

    //proceso una tupla String: palabras, Timestamp:timestamp de la ventana temporal
    val palabras = info.as[(String, Timestamp)]
      .flatMap(par => par._1.split("\\W+")
        .map(palabra => (palabra, par._2)))
      .toDF("palabra", "timestamp")

    //ventana de tiempo de 24 horas y con una duracion de slide de 60 minutos
    val conteoPalabrasCadaHora = palabras
      .groupBy(window($"timestamp", "1440 minutes", "60 minutes"), $"palabra")
      .count()


//Salida de datos en streaming a consola
    val query = conteoPalabrasCadaHora.writeStream
      .outputMode("update")
      .format("console")
      //.option("truncate", "false")
    .option("checkpointLocation","checkpoint")
      .start()

    query.awaitTermination()

    spark.sparkContext.stop()

  }

}
